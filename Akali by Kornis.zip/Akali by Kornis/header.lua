return {
    id = 'Akali',
    name = 'Akali',
    load = function()
      return player.charName == 'Akali'
    end
}
