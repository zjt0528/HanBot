return {
    id = 'AkaliKornis',
    name = 'Akali',
    load = function()
      return player.charName == 'Akali'
    end
}
